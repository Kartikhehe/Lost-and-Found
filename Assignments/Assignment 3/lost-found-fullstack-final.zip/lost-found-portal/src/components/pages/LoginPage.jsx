import LoginForm from '../auth/LoginForm';

const LoginPage = () => {
  return <LoginForm />;
};

export default LoginPage;

