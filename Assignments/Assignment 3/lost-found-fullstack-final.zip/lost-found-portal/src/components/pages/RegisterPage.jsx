import RegisterForm from '../auth/RegisterForm';

const RegisterPage = () => {
  return <RegisterForm />;
};

export default RegisterPage;

