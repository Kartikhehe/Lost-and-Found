import { Edit, Trash2 } from 'lucide-react';

const ItemCard = ({ item, onEdit, onDelete }) => {
  const isFound = item.status === 'found';
  
  return (
    <div className="bg-white rounded-xl overflow-visible shadow-lg transition-transform hover:-translate-y-1 bg-gray-50">
      <img
        src={item.imageUrl}
        alt={item.name}
        className="w-full h-auto object-cover rounded-t-lg max-h-96"
      />
      <div className="p-5 text-3xl">
        <h2 className="m-0 mb-2.5 text-4xl font-semibold">{item.name}</h2>
        <p className="mb-2">{item.description}</p>
        <p className="mb-1">
          <strong>Location:</strong> {item.location}
        </p>
        <p className="mb-1">
          <strong>Date:</strong> {item.date}
        </p>
        <p className="mb-1">
          <strong>Contact:</strong>{' '}
          <a href={`mailto:${item.contact}`} className="text-blue-600 hover:underline">
            {item.contact}
          </a>
        </p>
        <p className="mb-2">
          <strong>Category:</strong>{' '}
          <span className="bg-gray-100 text-black px-2.5 py-1 rounded-xl text-2xl ml-1">
            {item.category}
          </span>
        </p>
        
        <span
          className={`block mx-auto w-24 px-5 py-1.5 text-xl text-center rounded-2xl font-bold text-white mt-2.5 ${
            isFound ? 'bg-green-600' : 'bg-red-600'
          }`}
        >
          {isFound ? '✅ Found' : '❌ Lost'}
        </span>

        <div className="flex justify-start items-center mt-4">
          <button
            onClick={() => onEdit(item)}
            className="px-3.5 py-2 border-none rounded-md cursor-pointer mr-2.5 bg-yellow-400 text-black text-xl hover:bg-yellow-500 transition-colors flex items-center gap-1"
          >
            <Edit size={16} />
            Edit
          </button>
          <button
            onClick={() => onDelete(item.id)}
            className="px-3.5 py-2 border-none rounded-md cursor-pointer ml-auto bg-red-600 text-white text-xl hover:bg-red-700 transition-colors flex items-center gap-1"
          >
            <Trash2 size={16} />
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default ItemCard;

