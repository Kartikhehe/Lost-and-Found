import { useState, useEffect } from 'react';
import { X } from 'lucide-react';

const ItemModal = ({ isOpen, onClose, onSubmit, editItem = null }) => {
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    date: '',
    contact: '',
    imageUrl: '',
    category: '',
    status: '',
    description: ''
  });

  useEffect(() => {
    if (editItem) {
      setFormData(editItem);
    } else {
      setFormData({
        name: '',
        location: '',
        date: '',
        contact: '',
        imageUrl: '',
        category: '',
        status: '',
        description: ''
      });
    }
  }, [editItem, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
      onClick={handleBackdropClick}
    >
      <div className="bg-white mx-4 my-8 p-8 rounded-lg w-full max-w-lg shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-2.5 right-5 text-gray-600 text-3xl font-bold cursor-pointer hover:text-gray-800"
        >
          <X size={24} />
        </button>
        
        <h2 className="mb-6 text-2xl font-semibold">
          {editItem ? 'Edit Item' : 'Add New Item'}
        </h2>
        
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Item Name *"
            required
            className="p-2.5 text-xl rounded-md border border-gray-300"
          />
          
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleChange}
            placeholder="Location *"
            required
            className="p-2.5 text-xl rounded-md border border-gray-300"
          />
          
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
            className="p-2.5 text-xl rounded-md border border-gray-300"
          />
          
          <input
            type="email"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            placeholder="Contact Email *"
            required
            className="p-2.5 text-xl rounded-md border border-gray-300"
          />
          
          <input
            type="text"
            name="imageUrl"
            value={formData.imageUrl}
            onChange={handleChange}
            placeholder="Image URL"
            className="p-2.5 text-xl rounded-md border border-gray-300"
          />
          
          <select
            name="category"
            value={formData.category}
            onChange={handleChange}
            required
            className="p-2.5 text-xl rounded-md border border-gray-300"
          >
            <option value="">Select Category</option>
            <option value="electronics">Electronics</option>
            <option value="accessories">Accessories</option>
            <option value="books">Books</option>
          </select>
          
          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
            required
            className="p-2.5 text-xl rounded-md border border-gray-300"
          >
            <option value="">Status</option>
            <option value="found">✅ Found</option>
            <option value="lost">❌ Lost</option>
          </select>
          
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Description (optional)"
            rows="3"
            className="p-2.5 text-xl rounded-md border border-gray-300 resize-vertical"
          />
          
          <button
            type="submit"
            className="p-3 bg-blue-600 text-white text-xl border-none rounded-lg cursor-pointer hover:bg-blue-700 transition-colors"
          >
            {editItem ? 'Update' : 'Submit'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ItemModal;

