import { useState } from 'react';
import { Link } from 'react-router-dom';

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    remember: false
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle registration logic here
    console.log('Registration attempt:', formData);
    // For now, just redirect to login
    window.location.href = '/login';
  };

  return (
    <div className="min-h-screen bg-gray-200 flex justify-center items-center font-sans">
      <div className="bg-gray-300 p-8 rounded-xl shadow-lg w-80 text-center">
        <div className="mb-5">
          <img 
            src="/src/assets/image.png" 
            alt="User Avatar" 
            className="w-24 mx-auto rounded-full"
          />
        </div>
        
        <h2 className="mb-6 text-2xl font-semibold">Register here!!</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="text-left">
            <label htmlFor="username" className="block text-sm font-medium mb-1">
              Username *
            </label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              placeholder="Enter your Username"
              required
              className="w-full p-2.5 border border-gray-300 rounded-md text-sm"
            />
          </div>

          <div className="text-left">
            <label htmlFor="password" className="block text-sm font-medium mb-1">
              Password *
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter your Password"
              required
              className="w-full p-2.5 border border-gray-300 rounded-md text-sm"
            />
          </div>

          <div className="flex items-center text-left">
            <input
              type="checkbox"
              id="remember"
              name="remember"
              checked={formData.remember}
              onChange={handleChange}
              className="mr-2"
            />
            <label htmlFor="remember" className="text-sm">
              Remember me
            </label>
          </div>

          <button
            type="submit"
            className="w-full p-2.5 bg-blue-600 text-white text-base border-none rounded-md cursor-pointer mt-2.5 hover:bg-blue-700 transition-colors"
          >
            Register
          </button>

          <div className="mt-3 space-y-2">
            <Link 
              to="/forgot-password" 
              className="text-red-600 text-sm block hover:underline"
            >
              Forgot password?
            </Link>
            <Link 
              to="/login" 
              className="text-red-600 text-sm block hover:underline"
            >
              Already have an account? Login!
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegisterForm;

