const Filters = ({ statusFilter, categoryFilter, onStatusChange, onCategoryChange }) => {
  return (
    <section className="flex justify-center gap-2.5 mx-auto my-2.5 flex-wrap">
      <button
        onClick={() => onStatusChange('all')}
        className={`px-4 py-2.5 text-sm rounded-lg border border-red-600 text-xl cursor-pointer transition-colors ${
          statusFilter === 'all' 
            ? 'bg-blue-800 text-white' 
            : 'bg-blue-600 text-white hover:bg-blue-800'
        }`}
      >
        All
      </button>
      <button
        onClick={() => onStatusChange('found')}
        className={`px-4 py-2.5 text-sm rounded-lg border border-red-600 text-xl cursor-pointer transition-colors ${
          statusFilter === 'found' 
            ? 'bg-blue-800 text-white' 
            : 'bg-blue-600 text-white hover:bg-blue-800'
        }`}
      >
        ✅ Found
      </button>
      <button
        onClick={() => onStatusChange('lost')}
        className={`px-4 py-2.5 text-sm rounded-lg border border-red-600 text-xl cursor-pointer transition-colors ${
          statusFilter === 'lost' 
            ? 'bg-blue-800 text-white' 
            : 'bg-blue-600 text-white hover:bg-blue-800'
        }`}
      >
        ❌ Lost
      </button>
      
      <select
        value={categoryFilter}
        onChange={(e) => onCategoryChange(e.target.value)}
        className="px-4 py-2.5 text-sm rounded-lg border border-red-600 bg-blue-600 text-xl text-white cursor-pointer hover:bg-blue-800"
      >
        <option value="all">All Categories</option>
        <option value="electronics">Electronics</option>
        <option value="accessories">Accessories</option>
        <option value="books">Books</option>
      </select>
    </section>
  );
};

export default Filters;

