import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="bg-black text-white flex justify-between items-center text-2xl px-10 py-4">
      <div className="text-2xl font-bold">🧭 Lost & Found</div>
      <nav className="flex space-x-4">
        <Link to="/" className="text-white hover:text-gray-300 font-medium">Home</Link>
        <Link to="/blog" className="text-white hover:text-gray-300 font-medium">Blog</Link>
        <Link to="/lost" className="text-white hover:text-gray-300 font-medium">Lost</Link>
        <Link to="/found" className="text-white hover:text-gray-300 font-medium">Found</Link>
        <Link to="/contact" className="text-white hover:text-gray-300 font-medium">Contact</Link>
        <Link to="/about" className="text-white hover:text-gray-300 font-medium">About us</Link>
      </nav>
      <Link 
        to="/login" 
        className="bg-transparent border border-white px-3 py-1.5 text-white rounded-md text-2xl hover:bg-white hover:text-black transition-colors cursor-pointer"
      >
        Login
      </Link>
    </header>
  );
};

export default Header;

