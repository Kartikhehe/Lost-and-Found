import { useState } from 'react';
import Header from '../layout/Header';
import SearchBar from '../layout/SearchBar';
import Filters from '../layout/Filters';
import ItemCard from '../items/ItemCard';
import AddButton from '../items/AddButton';
import ItemModal from '../items/ItemModal';
import '../../App.css';

const HomePage = () => {
  // Sample data - in a real app this would come from an API
  const [items, setItems] = useState([
    {
      id: 1,
      name: 'Airpods',
      description: 'Boat Airpods found at 2nd floor of library.',
      location: 'Right side of 2nd floor',
      date: '08/07/2025',
      contact: 'founder@iit.com',
      category: 'electronics',
      status: 'found',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiRGzSWrZbvY1oaGQ_kd2vyy6lTzNPgzky8A&s'
    },
    {
      id: 2,
      name: 'Cycle',
      description: 'Cycle(HERO) of grey colour is lost from hall 10 canteen',
      location: 'Hall 10',
      date: '5/07/2025',
      contact: 'security_help@iit.com',
      category: 'accessories',
      status: 'lost',
      imageUrl: 'https://akm-img-a-in.tosshub.com/indiatoday/images/story/202103/IMG_20210326_181312_1200x768.jpeg?size=690:388'
    },
    {
      id: 3,
      name: 'Mobile phone',
      description: 'Mobile Phone found (realme) found in L 20.',
      location: 'L 20',
      date: '06/07/2025',
      contact: 'founder.iitk@email.com',
      category: 'electronics',
      status: 'found',
      imageUrl: 'https://i.pcmag.com/imagery/reviews/01UegEoFfj27rIbEM7VNtuO-1.fit_lim.size_298x174.v1744139698.jpg'
    },
    {
      id: 4,
      name: 'Key',
      description: 'Bunch of key found near DOAA canteen.',
      location: 'DOAA canteen',
      date: '07/06/2025',
      contact: 'finder123@example.com',
      category: 'accessories',
      status: 'found',
      imageUrl: 'https://www.hallslocksmiths.co.uk/wp-content/uploads/Copy-of-Unnamed-Design-7-1080x628.png'
    },
    {
      id: 5,
      name: 'Id card',
      description: 'IIT Kanpur Id.card found at stair of OAT.',
      location: 'OAT',
      date: '09/07/2025',
      contact: 'fonder878@example.com',
      category: 'accessories',
      status: 'found',
      imageUrl: '/src/assets/id.jpg'
    },
    {
      id: 6,
      name: 'Water bottle',
      description: 'Pink Water bottle find in NCL in CC-02.',
      location: 'NCL',
      date: '30/06/2025',
      contact: 'abcdef.iitk@email.com',
      category: 'accessories',
      status: 'lost',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSE18-V4F_9K7LNokSYMQmpBZ6b19MZM7rGuQ&s'
    }
  ]);

  // State for filters and search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  
  // State for modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);

  // Filter items based on search and filters
  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  // Handle search
  const handleSearch = () => {
    // Search is handled automatically through filteredItems
    console.log('Searching for:', searchQuery);
  };

  // Handle adding/editing items
  const handleSubmitItem = (formData) => {
    if (editItem) {
      // Update existing item
      setItems(items.map(item => 
        item.id === editItem.id ? { ...formData, id: editItem.id } : item
      ));
      setEditItem(null);
    } else {
      // Add new item
      const newItem = {
        ...formData,
        id: Date.now() // Simple ID generation
      };
      setItems([...items, newItem]);
    }
  };

  // Handle editing an item
  const handleEditItem = (item) => {
    setEditItem(item);
    setIsModalOpen(true);
  };

  // Handle deleting an item
  const handleDeleteItem = (itemId) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      setItems(items.filter(item => item.id !== itemId));
    }
  };

  // Handle opening modal for new item
  const handleOpenModal = () => {
    setEditItem(null);
    setIsModalOpen(true);
  };

  return (
    <div className="main-background min-h-screen">
      <Header />
      
      <SearchBar 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearch={handleSearch}
      />
      
      <Filters 
        statusFilter={statusFilter}
        categoryFilter={categoryFilter}
        onStatusChange={setStatusFilter}
        onCategoryChange={setCategoryFilter}
      />
      
      <main className="items-grid">
        {filteredItems.map(item => (
          <ItemCard 
            key={item.id}
            item={item}
            onEdit={handleEditItem}
            onDelete={handleDeleteItem}
          />
        ))}
      </main>
      
      <AddButton onClick={handleOpenModal} />
      
      <ItemModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleSubmitItem}
        editItem={editItem}
      />
    </div>
  );
};

export default HomePage;

