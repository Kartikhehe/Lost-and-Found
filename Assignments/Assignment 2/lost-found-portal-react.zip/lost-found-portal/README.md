# Lost & Found Portal - React Application

This is a fully functional Lost & Found portal built with React, converted from the original HTML, CSS, and JavaScript project. The application allows users to search, filter, add, edit, and delete lost and found items.

## Features

### ✅ Completed Features
- **Responsive Design**: Works on both desktop and mobile devices
- **Search Functionality**: Search items by name or location
- **Filter System**: Filter by status (All/Found/Lost) and category (Electronics/Accessories/Books)
- **Item Management**: Add, edit, and delete items
- **Modal Forms**: Clean modal interface for adding/editing items
- **Navigation**: Multi-page routing with React Router
- **Authentication Pages**: Login and Register forms
- **Real-time Updates**: Instant filtering and search results

### 🎨 UI/UX Improvements
- Modern React components with Tailwind CSS
- Lucide React icons for better visual appeal
- Smooth transitions and hover effects
- Clean, professional styling
- Background image preserved from original design

## Technology Stack

- **React 18** - Modern React with hooks
- **React Router DOM** - Client-side routing
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Beautiful icons
- **Vite** - Fast build tool and development server

## Project Structure

```
src/
├── components/
│   ├── auth/
│   │   ├── LoginForm.jsx
│   │   └── RegisterForm.jsx
│   ├── items/
│   │   ├── AddButton.jsx
│   │   ├── ItemCard.jsx
│   │   └── ItemModal.jsx
│   ├── layout/
│   │   ├── Filters.jsx
│   │   ├── Header.jsx
│   │   └── SearchBar.jsx
│   └── pages/
│       ├── HomePage.jsx
│       ├── LoginPage.jsx
│       └── RegisterPage.jsx
├── App.jsx
├── App.css
└── main.jsx
```

## Getting Started

### Prerequisites
- Node.js (v16 or higher)
- pnpm (or npm/yarn)

### Installation & Running

1. **Navigate to the project directory:**
   ```bash
   cd lost-found-portal
   ```

2. **Install dependencies:**
   ```bash
   pnpm install
   ```

3. **Start the development server:**
   ```bash
   pnpm run dev
   ```

4. **Open your browser and visit:**
   ```
   http://localhost:5173
   ```

### Building for Production

```bash
pnpm run build
```

The built files will be in the `dist/` directory.

## Key Improvements from Original

### 🔄 React Conversion Benefits
1. **Component-Based Architecture**: Reusable, maintainable components
2. **State Management**: Proper React state handling with useState hooks
3. **Event Handling**: Modern React event handlers instead of inline onclick
4. **Routing**: Single-page application with React Router
5. **Form Handling**: Controlled components with proper validation

### 🎯 Functionality Enhancements
1. **Real-time Search**: Instant filtering as you type
2. **Better State Management**: All data managed in React state
3. **Modal Management**: Proper modal state handling
4. **Form Validation**: Built-in HTML5 validation
5. **Responsive Design**: Mobile-first approach with Tailwind CSS

### 🚀 Performance Improvements
1. **Fast Refresh**: Instant updates during development
2. **Optimized Bundle**: Vite's optimized build process
3. **Component Reusability**: Efficient rendering with React
4. **Modern JavaScript**: ES6+ features and React hooks

## Usage Guide

### Adding New Items
1. Click the "Add New Item" button
2. Fill in the required fields (Name, Location, Date, Contact, Category, Status)
3. Optionally add an image URL and description
4. Click "Submit" to add the item

### Searching and Filtering
- **Search**: Type in the search bar to find items by name or location
- **Status Filter**: Click "All", "Found", or "Lost" buttons
- **Category Filter**: Use the dropdown to filter by category

### Editing Items
1. Click the "Edit" button on any item card
2. Modify the information in the modal
3. Click "Update" to save changes

### Navigation
- Use the header navigation to move between pages
- Login/Register pages are fully functional with form validation

## Development Notes

### State Management
The application uses React's built-in useState hooks for state management. The main state is managed in the HomePage component and passed down to child components via props.

### Styling Approach
- **Tailwind CSS**: Used for utility-first styling
- **Custom CSS**: Added for background image and specific styling needs
- **Responsive Design**: Mobile-first approach with responsive breakpoints

### Component Architecture
- **Separation of Concerns**: Each component has a single responsibility
- **Props Interface**: Clean prop interfaces for component communication
- **Event Handling**: Proper event bubbling and handling

## Future Enhancements

### Potential Improvements
1. **Backend Integration**: Connect to a real API/database
2. **Image Upload**: Allow users to upload images instead of URLs
3. **User Authentication**: Implement real login/logout functionality
4. **Email Notifications**: Send emails when items are found/lost
5. **Advanced Search**: Add more search filters and sorting options
6. **PWA Features**: Make it a Progressive Web App
7. **Dark Mode**: Add theme switching capability

### Technical Debt
1. **Data Persistence**: Currently uses local state (data resets on refresh)
2. **Error Handling**: Add comprehensive error boundaries
3. **Loading States**: Add loading indicators for better UX
4. **Form Validation**: Enhanced client-side validation
5. **Accessibility**: Improve ARIA labels and keyboard navigation

## Contributing

This project follows React best practices and modern development standards. When contributing:

1. Use functional components with hooks
2. Follow the existing component structure
3. Use Tailwind CSS for styling
4. Ensure responsive design
5. Test functionality across different screen sizes

## License

This project is converted from the original HTML/CSS/JavaScript implementation and maintains the same functionality while providing a modern React-based architecture.

